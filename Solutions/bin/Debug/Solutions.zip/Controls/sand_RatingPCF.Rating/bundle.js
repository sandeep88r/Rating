/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./Rating/Rating.tsx":
/*!***************************!*\
  !*** ./Rating/Rating.tsx ***!
  \***************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

eval("\n\nvar __extends = this && this.__extends || function () {\n  var _extendStatics = function extendStatics(d, b) {\n    _extendStatics = Object.setPrototypeOf || {\n      __proto__: []\n    } instanceof Array && function (d, b) {\n      d.__proto__ = b;\n    } || function (d, b) {\n      for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];\n    };\n    return _extendStatics(d, b);\n  };\n  return function (d, b) {\n    if (typeof b !== \"function\" && b !== null) throw new TypeError(\"Class extends value \" + String(b) + \" is not a constructor or null\");\n    _extendStatics(d, b);\n    function __() {\n      this.constructor = d;\n    }\n    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());\n  };\n}();\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.Ratings = void 0;\nvar React = __webpack_require__(/*! react */ \"react\");\nvar react_1 = __webpack_require__(/*! @fluentui/react */ \"@fluentui/react\");\nvar Ratings = /** @class */function (_super) {\n  __extends(Ratings, _super);\n  function Ratings(props) {\n    var _this = _super.call(this, props) || this;\n    _this.onRatingChange = function (event, rating) {\n      if (rating !== undefined) {\n        _this.setState({\n          currentRating: rating\n        });\n        _this.props.onRatingChange(rating);\n        console.log(\"current rating\", rating);\n      }\n    };\n    _this.state = {\n      currentRating: props.ratingvalue\n    };\n    return _this;\n  }\n  Ratings.prototype.render = function () {\n    return React.createElement(React.Fragment, null, React.createElement(\"div\", {\n      style: {\n        display: 'flex',\n        alignItems: 'center'\n      }\n    }, React.createElement(react_1.Rating, {\n      rating: this.state.currentRating,\n      max: 5,\n      onChange: this.onRatingChange\n    }), React.createElement(\"span\", {\n      style: {\n        marginLeft: 10\n      }\n    }, this.state.currentRating)));\n  };\n  return Ratings;\n}(React.Component);\nexports.Ratings = Ratings;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./Rating/Rating.tsx?");

/***/ }),

/***/ "./Rating/index.ts":
/*!*************************!*\
  !*** ./Rating/index.ts ***!
  \*************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

eval("\n\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.Rating = void 0;\nvar Rating_1 = __webpack_require__(/*! ./Rating */ \"./Rating/Rating.tsx\");\nvar React = __webpack_require__(/*! react */ \"react\");\nvar Rating = /** @class */function () {\n  function Rating() {\n    this.ratingValue = 0;\n  }\n  Rating.prototype.init = function (context, notifyOutputChanged, state) {\n    var ratingvalue = context.parameters.Ratingvalue.raw || 0;\n    this.ratingValue = ratingvalue;\n    this.notifyOutputChanged = notifyOutputChanged;\n  };\n  Rating.prototype.updateView = function (context) {\n    var _this = this;\n    return React.createElement(Rating_1.Ratings, {\n      ratingvalue: this.ratingValue,\n      onRatingChange: function onRatingChange(rating) {\n        _this.ratingValue = rating;\n        _this.notifyOutputChanged(); // notify the framework that the output has changed\n      }\n    });\n  };\n\n  Rating.prototype.getOutputs = function () {\n    return {\n      Ratingvalue: this.ratingValue\n    };\n  };\n  Rating.prototype.destroy = function () {\n    // Add code to cleanup control if necessary\n  };\n  return Rating;\n}();\nexports.Rating = Rating;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./Rating/index.ts?");

/***/ }),

/***/ "@fluentui/react":
/*!*************************************!*\
  !*** external "FluentUIReactv8290" ***!
  \*************************************/
/***/ ((module) => {

module.exports = FluentUIReactv8290;

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "React" ***!
  \************************/
/***/ ((module) => {

module.exports = React;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./Rating/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('RatingPCF.Rating', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.Rating);
} else {
	var RatingPCF = RatingPCF || {};
	RatingPCF.Rating = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.Rating;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}